# ARES Robotics — Round 2 Software Department

## Python Task Submission

### 1.1 Average Sensor Reading

Given:

`[10, 12, 11, 50, 13]`

Formula:

`Average = Sum of readings / Number of readings`

Sum = `10 + 12 + 11 + 50 + 13 = 96`

Number of readings = `5`

Average = `96 / 5 = 19.2`

**Final Answer: 19.2**

---

## 1.2 Obstacle Avoidance — Approach

The robot follows a continuous **Sense → Decide → Act** cycle.

1. **Sense:** Read the current distance from the front distance sensor.
2. **Decide:** Compare the distance with a safety threshold (20 cm).
3. **Act:**
   - If distance is greater than 20 cm, both motors move forward.
   - If distance is 20 cm or less, the robot stops first and then turns right.
4. A `while`/repeated loop is required because the robot must continuously
   monitor the environment.

For this submission, the hardware functions are simulated so that the code
can run on any computer without a robot. On real hardware, `get_distance()`,
`move_forward()`, `stop_robot()`, and `turn_right()` would be connected to
the actual sensor and motor-control libraries.

## Why stop before turning?

Stopping before turning reduces the chance of the robot moving into the
obstacle while changing direction. It also makes the control logic simple
and safe.

## Complexity

- Average calculation: **O(n)** time and **O(1)** extra space.
- Each obstacle-avoidance cycle performs a constant amount of work: **O(1)**.
- The control loop continues for as long as the robot is operating.

## Files

- `main.py` — complete runnable Python solution.
- `README.md` — explanation, answers, and implementation details.
- `sample_output.txt` — sample terminal output.
- `requirements.txt` — no external packages required.

## How to run

```bash
python main.py
```

Python 3.x is sufficient. No external libraries are required.

## Hardware adaptation

For a real robot, replace the simulation functions with the society's actual
sensor/motor APIs. The control structure remains:

```text
SENSE → DECIDE → ACT → repeat
```
