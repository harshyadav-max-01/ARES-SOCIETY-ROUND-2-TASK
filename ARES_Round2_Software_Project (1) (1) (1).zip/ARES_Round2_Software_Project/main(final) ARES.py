"""
ARES Robotics - Round 2 Software Department
Task: Sensor Average + Differential-Drive Obstacle Avoidance

This program contains:
1. Average sensor reading calculation.
2. Basic Sense -> Decide -> Act obstacle-avoidance logic.

The robot functions below are simulation functions. On a real robot, they
would be replaced by the actual motor-control and distance-sensor APIs.
"""
## question 1.1: Average Sensor Reading:

import time


SENSOR_READINGS = [10, 12, 11, 50, 13]
OBSTACLE_THRESHOLD_CM = 20


def calculate_average(readings):
    
    if not readings:
        raise ValueError("Sensor readings cannot be empty.")
    return sum(readings) / len(readings)


## 1.2 question.
##Approach
##The robot will follow a continuous Sense → Decide → Act cycle:
##1.) Sense: Read the current distance from the front distance sensor.
"""2.) Decide: Use an if-else condition:
   If the distance is greater than the safety limit, there is no obstacle → move forward.
   Otherwise, an obstacle is detected → stop first, then turn."""
##3.) Act: Control the left and right motors accordingly.
##4.)A while True loop keeps repeating these steps so the robot continuously monitors its surroundings.

def get_distance():
    """Simulated distance sensor.

    In real hardware, replace this with the sensor's distance-reading API.
    """
    return 25


def move_forward():
    """Both motors move forward."""
    print("ACT: Both motors -> FORWARD")


def stop_robot():
    """Stop both motors before changing direction."""
    print("ACT: Both motors -> STOP")


def turn_right():
    """Differential-drive right turn."""
    print("ACT: Left motor -> FORWARD | Right motor -> STOP")


def obstacle_avoidance():
    """Continuously Sense -> Decide -> Act."""
    print("\n--- Obstacle Avoidance Simulation ---")

    # In a real robot this loop would normally run continuously.
    # A finite number of iterations keeps this demonstration runnable.
    while True:
        distance = get_distance()

        print(f"SENSE: Distance = {distance} cm")

        if distance <= OBSTACLE_THRESHOLD_CM:
            print("DECIDE: Obstacle detected!")
            stop_robot()
            time.sleep(0.5)

            turn_right()
            time.sleep(1)
        else:
            print("DECIDE: Path is clear.")
            move_forward()

        print(f"Cycle {cycle + 1} complete.\n")


def main():
    average = calculate_average(SENSOR_READINGS)

    print("1.1 Average Sensor Reading")
    print(f"Readings: {SENSOR_READINGS}")
    print(f"Sum: {sum(SENSOR_READINGS)}")
    print(f"Number of readings: {len(SENSOR_READINGS)}")
    print(f"Average: {average:.2f}")

    obstacle_avoidance()


if __name__ == "__main__":
    main()
